//
//  EatOutViewController.swift
//  FIT3178-Final-Assignment
//
//  Created by Jit Yap on 3/5/2023.
//

import UIKit
import MapKit

class EatOutViewController: UIViewController, MKMapViewDelegate, CLLocationManagerDelegate {
    
    let locationManager = CLLocationManager()
    let YELP_API_KEY = "vMFlX6Z10bNvZdMnPutcdw4U2P7IY8QkZZnlLe8r2zFfNSJN61l0OdP0PKd6a3QhCdAwd5RZhCfoMkp6_sX6ZSsIoLVTTHtJic8fSuFwoEVxpFUQ66AugCdFf4tUZHYx"
    
    var currentuserlongitutde: Double?
    var currentuserlatitude: Double?
    var newrestaurants = [RestaurantData]()


    @IBOutlet weak var eatoutlocationmap: MKMapView!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        eatoutlocationmap.delegate = self
        locationManager.delegate = self
        
        //monash location
//        let monashClayton = CLLocationCoordinate2D(latitude: -37.9105599, longitude: 145.1348545)
//        let monashRegion = MKCoordinateRegion(center: monashClayton, latitudinalMeters: 1000, longitudinalMeters: 10000)
//        let theatreAnnotation = MKPointAnnotation()
//        theatreAnnotation.coordinate = monashClayton
//        theatreAnnotation.title = "monash brutha"
//        theatreAnnotation.subtitle = "rip fit3178"
//        eatoutlocationmap.setRegion(monashRegion, animated: true)
//        eatoutlocationmap.addAnnotation(theatreAnnotation)
        
        CheckLocationAuthorization()

        // Do any additional setup after loading the view.
    }
    
    func mapView(_ mapView: MKMapView, didUpdate userLocation: MKUserLocation) {
        let mapRegion = MKCoordinateRegion(center: userLocation.coordinate, latitudinalMeters: 1000, longitudinalMeters: 1000)
        mapView.setRegion(mapRegion, animated: true)
        currentuserlatitude = userLocation.coordinate.latitude
        currentuserlongitutde = userLocation.coordinate.longitude
        
        Task{
//            URLSession.shared.invalidateAndCancel()
            await FetchRestaurantInformations()
        }
        print(newrestaurants.count)
    }
    
    func locationManager(_ manager: CLLocationManager, didChangeAuthorization status: CLAuthorizationStatus) {
        eatoutlocationmap.showsUserLocation = (status == .authorizedWhenInUse)
    }
    
    func CheckLocationAuthorization(){
        let status = locationManager.authorizationStatus
        switch status{
        case.notDetermined:
            locationManager.requestWhenInUseAuthorization()
        case .restricted:
            print("Your location is restricted")
        case .denied:
            print("You denied this app location permission")
        case .authorizedAlways, .authorizedWhenInUse:
            break
        default:
            break
        }
    }
    
    func FetchRestaurantInformations()async{
        var components = URLComponents()
        components.host = "api.yelp.com"
        components.path = "/v3/businesses/search"
        components.scheme = "https"
        components.queryItems = [URLQueryItem]()
        components.queryItems?.append(URLQueryItem(name: "latitude", value: String(currentuserlatitude!)))
        components.queryItems?.append(URLQueryItem(name: "longitude", value: String(currentuserlongitutde!)))
        components.queryItems?.append(URLQueryItem(name: "limit", value: String(20)))
        
        guard let requestURL = components.url else{
            print("Invalid URL.")
            return
        }
        
        var urlRequest = URLRequest(url:requestURL)
        urlRequest.httpMethod = "GET"
        urlRequest.addValue("Bearer \(YELP_API_KEY)", forHTTPHeaderField: "Authorization")
            
        do{
            let(data, response) = try await URLSession.shared.data(for: urlRequest)
            do{
                let decoder = JSONDecoder()
                let restaurantData = try decoder.decode(RestaurantsData.self, from: data)
                if let restaurant = restaurantData.restaurants{
                    print(restaurant)
                    newrestaurants.append(contentsOf: restaurant)
                    print(newrestaurants.count)
                    for restaurant in newrestaurants {
                        print(restaurant.name)
                        }
                    }
                }
        }catch let error{
            print(error)
        }
    }
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
