//
//  EatOutMapCollectionViewCell.swift
//  FIT3178-Final-Assignment
//
//  Created by Jit Yap on 3/5/2023.
//

import UIKit
import MapKit

class EatOutMapCollectionViewCell: UICollectionViewCell {
    
    @IBOutlet weak var currentuserlocationmap: MKMapView!
}
