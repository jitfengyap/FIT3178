//
//  RestaurantsData.swift
//  FIT3178-Final-Assignment
//
//  Created by Jit Yap on 5/5/2023.
//

import UIKit

class RestaurantsData: NSObject, Decodable{
    
    // the header of the restaurant data given in the form of javascript from the api.
    
    var restaurants: [RestaurantData]?

    private enum CodingKeys: String, CodingKey{
        case restaurants = "businesses"
    }
}
