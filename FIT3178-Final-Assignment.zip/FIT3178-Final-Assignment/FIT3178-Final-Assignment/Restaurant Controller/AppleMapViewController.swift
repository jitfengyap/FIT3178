//
//  AppleMapViewController.swift
//  FIT3178-Final-Assignment
//
//  Created by Jit Yap on 23/4/2023.
//

import UIKit
import MapKit

class AppleMapViewController: UIViewController, MKMapViewDelegate, CLLocationManagerDelegate{

    let locationManager = CLLocationManager()
    
    var restaurantlocationlatitde: Double?
    var restaurantlocationlongitude: Double?
    
    @IBOutlet weak var applemap: MKMapView!
    
    // instantiate the delegates and get the direction between the user and restaurant.
    override func viewDidLoad() {
        super.viewDidLoad()
        
        locationManager.delegate = self
        applemap.delegate = self
        
        getDirections()
    }
    
    //first calculate the distance between the user and the restaurant and display it onto the apple map.
    func getDirections(){
        let sourceCoodinate = (locationManager.location?.coordinate)!
        let sourcePlacemark = MKPlacemark(coordinate: sourceCoodinate)
        let destinationPlacemark = MKPlacemark(coordinate: CLLocationCoordinate2D(latitude: restaurantlocationlatitde!, longitude: restaurantlocationlongitude!))
        
        let sourceItem = MKMapItem(placemark: sourcePlacemark)
        let destItem = MKMapItem(placemark: destinationPlacemark)
        
        let destinationRequest = MKDirections.Request()
        destinationRequest.source = sourceItem
        destinationRequest.destination = destItem
        destinationRequest.transportType = .automobile
        destinationRequest.requestsAlternateRoutes = true
        
        let direction = MKDirections(request: destinationRequest)

        direction.calculate{(response, error) in
            guard let response = response else{
                if let error = error {
                    print("error is detected")
                }
                return
            }
            let route = response.routes[0]
            self.applemap.addOverlay(route.polyline)
            self.applemap.setVisibleMapRect(route.polyline.boundingMapRect, animated: true)
            
        }

    }
    
    // if the user move, then the user location will keep updating.
    func mapView(_ mapView: MKMapView, didUpdate userLocation: MKUserLocation) {
        let mapRegion = MKCoordinateRegion(center: userLocation.coordinate, latitudinalMeters: 1000, longitudinalMeters: 1000)
        mapView.setRegion(mapRegion, animated: true)
    }

    // check if the user have provided permission to get his location
    func locationManager(_ manager: CLLocationManager, didChangeAuthorization status: CLAuthorizationStatus) {
        applemap.showsUserLocation = (status == .authorizedWhenInUse)
    }
    
    // check if the status is one of the cases below
    // each cases will determine which outputs.
    func CheckLocationAuthorization(){
        let status = locationManager.authorizationStatus
        switch status{
        case.notDetermined:
            locationManager.requestWhenInUseAuthorization()
        case .restricted:
            print("Your location is restricted")
        case .denied:
            print("You denied this app location permission")
        case .authorizedAlways, .authorizedWhenInUse:
            break
        default:
            break
        }
    }
    
    // create a line set between the user and the selected restaurant and set the line of the route to blue.
    func mapView(_ mapView: MKMapView, rendererFor overlay: MKOverlay) -> MKOverlayRenderer {
        let render = MKPolylineRenderer(overlay: overlay as! MKPolyline)
        render.strokeColor = .blue
        return render
    }
    

}
