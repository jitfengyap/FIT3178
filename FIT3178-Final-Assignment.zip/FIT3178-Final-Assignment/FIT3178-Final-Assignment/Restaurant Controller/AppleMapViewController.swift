//
//  AppleMapViewController.swift
//  FIT3178-Final-Assignment
//
//  Created by Jit Yap on 23/4/2023.
//

import UIKit
import MapKit

class AppleMapViewController: UIViewController, MKMapViewDelegate, CLLocationManagerDelegate{

    let locationManager = CLLocationManager()
    
    var restaurantlocationlatitde: Double?
    var restaurantlocationlongitude: Double?
    
    @IBOutlet weak var applemap: MKMapView!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        locationManager.delegate = self
        applemap.delegate = self
        
        getDirections()
        // Do any additional setup after loading the view.
    }
    
    func getDirections(){
//        guard let location = locationManager.location?.coordinate else{
//            return
//        }
//        let request = createDirectionRequest(from: location)
        
        let sourceCoodinate = (locationManager.location?.coordinate)!
        let sourcePlacemark = MKPlacemark(coordinate: sourceCoodinate)
        let destinationPlacemark = MKPlacemark(coordinate: CLLocationCoordinate2D(latitude: restaurantlocationlatitde!, longitude: restaurantlocationlongitude!))
        
        let sourceItem = MKMapItem(placemark: sourcePlacemark)
        let destItem = MKMapItem(placemark: destinationPlacemark)
        
        let destinationRequest = MKDirections.Request()
        destinationRequest.source = sourceItem
        destinationRequest.destination = destItem
        destinationRequest.transportType = .automobile
        destinationRequest.requestsAlternateRoutes = true
        
        let direction = MKDirections(request: destinationRequest)

        direction.calculate{(response, error) in
            guard let response = response else{
                if let error = error {
                    print("error is detected")
                }
                return
            }
            let route = response.routes[0]
            self.applemap.addOverlay(route.polyline)
            self.applemap.setVisibleMapRect(route.polyline.boundingMapRect, animated: true)
            
        }

    }
    
//    func createDirectionRequest(from coordinate: CLLocationCoordinate2D) -> MKDirections.Request{
//        let destinationCoodinate = CLLocationCoordinate2D(latitude: restaurantlocationlatitde!, longitude: restaurantlocationlongitude!)
//        let startinglocation = MKPlacemark(coordinate: coordinate)
//        let destination = MKPlacemark(coordinate: destinationCoodinate)
//
//        let request = MKDirections.Request()
//        request.source = MKMapItem(placemark: startinglocation)
//        request.destination = MKMapItem(placemark: destination)
//        request.transportType = .automobile
//        request.requestsAlternateRoutes = true
//        return request
//    }
    
    
    func mapView(_ mapView: MKMapView, didUpdate userLocation: MKUserLocation) {
        let mapRegion = MKCoordinateRegion(center: userLocation.coordinate, latitudinalMeters: 1000, longitudinalMeters: 1000)
        mapView.setRegion(mapRegion, animated: true)
    }

    func locationManager(_ manager: CLLocationManager, didChangeAuthorization status: CLAuthorizationStatus) {
        applemap.showsUserLocation = (status == .authorizedWhenInUse)
    }
    
    func CheckLocationAuthorization(){
        let status = locationManager.authorizationStatus
        switch status{
        case.notDetermined:
            locationManager.requestWhenInUseAuthorization()
        case .restricted:
            print("Your location is restricted")
        case .denied:
            print("You denied this app location permission")
        case .authorizedAlways, .authorizedWhenInUse:
            break
        default:
            break
        }
    }
    
    func mapView(_ mapView: MKMapView, rendererFor overlay: MKOverlay) -> MKOverlayRenderer {
        let render = MKPolylineRenderer(overlay: overlay as! MKPolyline)
        render.strokeColor = .blue
        return render
    }
    
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
