//
//  EatoutCollectionViewCell.swift
//  FIT3178-Final-Assignment
//
//  Created by Jit Yap on 3/5/2023.
//

import UIKit

class EatoutCollectionViewCell: UICollectionViewCell {
    // label and image being used to display each restaurant
    @IBOutlet weak var restaurantnamelabel: UILabel!
    @IBOutlet weak var restaurantUIImageView: UIImageView!
}
