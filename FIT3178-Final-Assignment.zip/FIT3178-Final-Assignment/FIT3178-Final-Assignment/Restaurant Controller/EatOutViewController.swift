//
//  EatOutViewController.swift
//  FIT3178-Final-Assignment
//
//  Created by Jit Yap on 3/5/2023.
//

import UIKit
import MapKit

enum RestaurantImageError: Error{
    case invalidServerResponse
    case invalidShowURL
    case invalidRecipeImageURL
}

class EatOutViewController: UIViewController, MKMapViewDelegate, CLLocationManagerDelegate {
    
    let locationManager = CLLocationManager()
    let YELP_API_KEY = "vMFlX6Z10bNvZdMnPutcdw4U2P7IY8QkZZnlLe8r2zFfNSJN61l0OdP0PKd6a3QhCdAwd5RZhCfoMkp6_sX6ZSsIoLVTTHtJic8fSuFwoEVxpFUQ66AugCdFf4tUZHYx"
    
    var currentuserlongitutde: Double?
    var currentuserlatitude: Double?
    var newrestaurants = [RestaurantData]()
    var restaurantimages = [UIImage?]()
    
    //image loading
    var imageisDownloading = false
    var imageShown = true
    
    //selected restaurants
    var selectedrestaurant: RestaurantData?
    var selectedrestaurantimages: UIImage?


    @IBOutlet weak var RestaurantInfoCollectionView: UICollectionView!
    
    @IBOutlet weak var eatoutlocationmap: MKMapView!
    
    //  instantiate delegate to aquire the location of user.
    override func viewDidLoad() {
        super.viewDidLoad()
        
        eatoutlocationmap.delegate = self
        locationManager.delegate = self
        CheckLocationAuthorization()
        
        RestaurantInfoCollectionView.dataSource = self
        RestaurantInfoCollectionView.delegate = self
        RestaurantInfoCollectionView.collectionViewLayout = UICollectionViewFlowLayout()
        RestaurantInfoCollectionView.reloadData()
    }
    
    // acquire the restaurant near user location and zoom into closer the user on the map.
    func mapView(_ mapView: MKMapView, didUpdate userLocation: MKUserLocation) {
        let mapRegion = MKCoordinateRegion(center: userLocation.coordinate, latitudinalMeters: 1000, longitudinalMeters: 1000)
        mapView.setRegion(mapRegion, animated: true)
        currentuserlatitude = userLocation.coordinate.latitude
        currentuserlongitutde = userLocation.coordinate.longitude
        
        Task{
//            URLSession.shared.invalidateAndCancel()
            await FetchRestaurantInformations()
        }
    }
    
    // check if the user gave permission for their location and show it on the map.
    func locationManager(_ manager: CLLocationManager, didChangeAuthorization status: CLAuthorizationStatus) {
        eatoutlocationmap.showsUserLocation = (status == .authorizedWhenInUse)
    }
    
    //check what the user authorization.
    func CheckLocationAuthorization(){
        let status = locationManager.authorizationStatus
        switch status{
        case.notDetermined:
            locationManager.requestWhenInUseAuthorization()
        case .restricted:
            print("Your location is restricted")
        case .denied:
            print("You denied this app location permission")
        case .authorizedAlways, .authorizedWhenInUse:
//            currentuserlatitude = locationManager.location?.coordinate.latitude
//            currentuserlongitutde = locationManager.location?.coordinate.longitude
            break
        default:
            break
        }
    }
    
    // fetch the restaurant close to the current location of the user using yelp api.
    func FetchRestaurantInformations()async{
        var components = URLComponents()
        components.host = "api.yelp.com"
        components.path = "/v3/businesses/search"
        components.scheme = "https"
        components.queryItems = [URLQueryItem]()
        components.queryItems?.append(URLQueryItem(name: "latitude", value: String(currentuserlatitude!)))
        components.queryItems?.append(URLQueryItem(name: "longitude", value: String(currentuserlongitutde!)))
        components.queryItems?.append(URLQueryItem(name: "limit", value: String(20)))
        
        guard let requestURL = components.url else{
            print("Invalid URL.")
            return
        }
        
        var urlRequest = URLRequest(url:requestURL)
        urlRequest.httpMethod = "GET"
        urlRequest.addValue("Bearer \(YELP_API_KEY)", forHTTPHeaderField: "Authorization")
            
        do{
            let(data, response) = try await URLSession.shared.data(for: urlRequest)
            do{
                let decoder = JSONDecoder()
                let restaurantData = try decoder.decode(RestaurantsData.self, from: data)
                if let restaurant = restaurantData.restaurants{
                    newrestaurants.append(contentsOf: restaurant)
                    for _ in newrestaurants {
                        restaurantimages.append(nil)
                        }
                    RestaurantInfoCollectionView.reloadData()
                    }
                }
        }catch let error{
            print(error)
        }
    }

}

// created a collection view in the view controller
extension EatOutViewController: UICollectionViewDataSource{
    
    // return total section in the collection view
    func numberOfSections(in collectionView: UICollectionView) -> Int {
        return 1
    }
    
    // return number of rows for each section
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return newrestaurants.count
    }
    
    // display all the information about the restaurant and download each restaurant image
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "eatoutcollectionviewcell", for: indexPath) as! EatoutCollectionViewCell
        
        let restaurant = newrestaurants[indexPath.row]
        cell.restaurantnamelabel.text = restaurant.name
        
        cell.restaurantUIImageView?.image = restaurantimages[indexPath.row]
        if cell.restaurantUIImageView?.image == nil{
            imageisDownloading = false
        }
        
        if let image = restaurantimages[indexPath.row]{
            cell.restaurantUIImageView?.image = image
        }else if imageisDownloading == false, let imageURL = restaurant.imageURL{
            let requestURL = URL(string: imageURL)
            if let requestURL{
                Task{
                    print("Downloading image: " + imageURL)
                    imageisDownloading = true
                    do{
                        let (data, response) = try await
                        URLSession.shared.data(from: requestURL)
                        guard let httpResponse = response as? HTTPURLResponse,
                              httpResponse.statusCode == 200 else{
                            imageisDownloading = false
                            throw RestaurantImageError.invalidServerResponse
                        }
                        if let image = UIImage(data:data){
                            print("Image downloaded successfully: " + imageURL)
                            let croppedImage = cropimage(image: image)
                            restaurantimages[indexPath.row] = croppedImage
                            await MainActor.run{
                                collectionView.reloadItems(at:[indexPath])
                            }
                        }
                        else{
                            print("Image Invalid: " + imageURL)
                            imageisDownloading = false
                        }
                    }
                    catch{
                        print(error.localizedDescription)
                    }
                }
            }
            else{
                print("Error: URL not valid: " + imageURL)
            }
        }
        return cell
    }
    
    // allow user to select each collection view
    func collectionView(_ collectionView: UICollectionView, shouldSelectItemAt indexPath: IndexPath) -> Bool {
        return true
    }

    // if the user select the collection view row, segue to restaurant information view controlelr.
    func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
        selectedrestaurant = newrestaurants[indexPath.row]
        selectedrestaurantimages = restaurantimages[indexPath.row]
        performSegue(withIdentifier: "restaurantInfoSegue", sender: self)
    }
    
    // crop all the image so that it comes in as a square
    func cropimage(image: UIImage) -> UIImage?{
        let sideLength = min(image.size.width, image.size.height)
        let originX = (image.size.width - sideLength) / 2
        let originY = (image.size.height - sideLength) / 2
        let cropRect = CGRect(x:originX, y: originY, width: sideLength, height:sideLength)
        guard let cgImage = image.cgImage?.cropping(to: cropRect)else{
            return nil
        }
        return UIImage(cgImage: cgImage)
    }
    
    // before segue, transfer information to the respective controller.
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        if segue.identifier == "restaurantInfoSegue"{
            let destination = segue.destination as! RestaurantInformationViewController
            destination.restaurantdata = selectedrestaurant
            destination.restaurantdataimage = selectedrestaurantimages
        }
    }
}

    // make sure each collection view are the same size.
extension EatOutViewController: UICollectionViewDelegateFlowLayout{
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, sizeForItemAt indexPath: IndexPath) -> CGSize {
        return CGSize(width: 175, height: 175)
    }
}
 
