//
//  EatOutViewController.swift
//  FIT3178-Final-Assignment
//
//  Created by Jit Yap on 3/5/2023.
//

import UIKit
import MapKit

enum RestaurantImageError: Error{
    case invalidServerResponse
    case invalidShowURL
    case invalidRecipeImageURL
}

class EatOutViewController: UIViewController, MKMapViewDelegate, CLLocationManagerDelegate {
    
    let locationManager = CLLocationManager()
    let YELP_API_KEY = "vMFlX6Z10bNvZdMnPutcdw4U2P7IY8QkZZnlLe8r2zFfNSJN61l0OdP0PKd6a3QhCdAwd5RZhCfoMkp6_sX6ZSsIoLVTTHtJic8fSuFwoEVxpFUQ66AugCdFf4tUZHYx"
    
    var currentuserlongitutde: Double?
    var currentuserlatitude: Double?
    var newrestaurants = [RestaurantData]()
    var restaurantimages = [UIImage?]()
    
    //image loading
    var imageisDownloading = false
    var imageShown = true
    
    //selected restaurants
    var selectedrestaurant: RestaurantData?
    var selectedrestaurantimages: UIImage?


    @IBOutlet weak var RestaurantInfoCollectionView: UICollectionView!
    
    @IBOutlet weak var eatoutlocationmap: MKMapView!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        eatoutlocationmap.delegate = self
        locationManager.delegate = self
        
        //monash location
//        let monashClayton = CLLocationCoordinate2D(latitude: -37.9105599, longitude: 145.1348545)
//        let monashRegion = MKCoordinateRegion(center: monashClayton, latitudinalMeters: 1000, longitudinalMeters: 10000)
//        let theatreAnnotation = MKPointAnnotation()
//        theatreAnnotation.coordinate = monashClayton
//        theatreAnnotation.title = "monash brutha"
//        theatreAnnotation.subtitle = "rip fit3178"
//        eatoutlocationmap.setRegion(monashRegion, animated: true)
//        eatoutlocationmap.addAnnotation(theatreAnnotation)
        
        CheckLocationAuthorization()
        
        RestaurantInfoCollectionView.dataSource = self
        RestaurantInfoCollectionView.delegate = self
        RestaurantInfoCollectionView.collectionViewLayout = UICollectionViewFlowLayout()
        RestaurantInfoCollectionView.reloadData()
//        if let _ = currentuserlongitutde, let _ = currentuserlatitude{
//            Task{
//                URLSession.shared.invalidateAndCancel()
//                await FetchRestaurantInformations()
//            }
//        }
        // Do any additional setup after loading the view.
    }
    
    func mapView(_ mapView: MKMapView, didUpdate userLocation: MKUserLocation) {
        let mapRegion = MKCoordinateRegion(center: userLocation.coordinate, latitudinalMeters: 1000, longitudinalMeters: 1000)
        mapView.setRegion(mapRegion, animated: true)
        currentuserlatitude = userLocation.coordinate.latitude
        currentuserlongitutde = userLocation.coordinate.longitude
        
        Task{
//            URLSession.shared.invalidateAndCancel()
            await FetchRestaurantInformations()
        }
    }
    
    func locationManager(_ manager: CLLocationManager, didChangeAuthorization status: CLAuthorizationStatus) {
        eatoutlocationmap.showsUserLocation = (status == .authorizedWhenInUse)
    }
    
    func CheckLocationAuthorization(){
        let status = locationManager.authorizationStatus
        switch status{
        case.notDetermined:
            locationManager.requestWhenInUseAuthorization()
        case .restricted:
            print("Your location is restricted")
        case .denied:
            print("You denied this app location permission")
        case .authorizedAlways, .authorizedWhenInUse:
//            currentuserlatitude = locationManager.location?.coordinate.latitude
//            currentuserlongitutde = locationManager.location?.coordinate.longitude
            break
        default:
            break
        }
    }
    
    func FetchRestaurantInformations()async{
        var components = URLComponents()
        components.host = "api.yelp.com"
        components.path = "/v3/businesses/search"
        components.scheme = "https"
        components.queryItems = [URLQueryItem]()
        components.queryItems?.append(URLQueryItem(name: "latitude", value: String(currentuserlatitude!)))
        components.queryItems?.append(URLQueryItem(name: "longitude", value: String(currentuserlongitutde!)))
        components.queryItems?.append(URLQueryItem(name: "limit", value: String(20)))
        
        guard let requestURL = components.url else{
            print("Invalid URL.")
            return
        }
        
        var urlRequest = URLRequest(url:requestURL)
        urlRequest.httpMethod = "GET"
        urlRequest.addValue("Bearer \(YELP_API_KEY)", forHTTPHeaderField: "Authorization")
            
        do{
            let(data, response) = try await URLSession.shared.data(for: urlRequest)
            do{
                let decoder = JSONDecoder()
                let restaurantData = try decoder.decode(RestaurantsData.self, from: data)
                if let restaurant = restaurantData.restaurants{
                    newrestaurants.append(contentsOf: restaurant)
                    for _ in newrestaurants {
                        restaurantimages.append(nil)
                        }
                    RestaurantInfoCollectionView.reloadData()
                    }
                }
        }catch let error{
            print(error)
        }
    }
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */
}

extension EatOutViewController: UICollectionViewDataSource{
    
    func numberOfSections(in collectionView: UICollectionView) -> Int {
        return 1
    }
    
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return newrestaurants.count
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "eatoutcollectionviewcell", for: indexPath) as! EatoutCollectionViewCell
        
        let restaurant = newrestaurants[indexPath.row]
        cell.restaurantnamelabel.text = restaurant.name
        
        cell.restaurantUIImageView?.image = restaurantimages[indexPath.row]
        if cell.restaurantUIImageView?.image == nil{
            imageisDownloading = false
        }
        
        if let image = restaurantimages[indexPath.row]{
            cell.restaurantUIImageView?.image = image
        }else if imageisDownloading == false, let imageURL = restaurant.imageURL{
            let requestURL = URL(string: imageURL)
            if let requestURL{
                Task{
                    print("Downloading image: " + imageURL)
                    imageisDownloading = true
                    do{
                        let (data, response) = try await
                        URLSession.shared.data(from: requestURL)
                        guard let httpResponse = response as? HTTPURLResponse,
                              httpResponse.statusCode == 200 else{
                            imageisDownloading = false
                            throw RestaurantImageError.invalidServerResponse
                        }
                        if let image = UIImage(data:data){
                            print("Image downloaded successfully: " + imageURL)
                            let croppedImage = cropimage(image: image)
                            restaurantimages[indexPath.row] = croppedImage
                            await MainActor.run{
                                collectionView.reloadItems(at:[indexPath])
                            }
                        }
                        else{
                            print("Image Invalid: " + imageURL)
                            imageisDownloading = false
                        }
                    }
                    catch{
                        print(error.localizedDescription)
                    }
                }
            }
            else{
                print("Error: URL not valid: " + imageURL)
            }
        }
        return cell
    }
    
    func collectionView(_ collectionView: UICollectionView, shouldSelectItemAt indexPath: IndexPath) -> Bool {
        return true
    }

    func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
        selectedrestaurant = newrestaurants[indexPath.row]
        selectedrestaurantimages = restaurantimages[indexPath.row]
        performSegue(withIdentifier: "restaurantInfoSegue", sender: self)
    }
    
    func cropimage(image: UIImage) -> UIImage?{
        let sideLength = min(image.size.width, image.size.height)
        let originX = (image.size.width - sideLength) / 2
        let originY = (image.size.height - sideLength) / 2
        let cropRect = CGRect(x:originX, y: originY, width: sideLength, height:sideLength)
        guard let cgImage = image.cgImage?.cropping(to: cropRect)else{
            return nil
        }
        return UIImage(cgImage: cgImage)
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        if segue.identifier == "restaurantInfoSegue"{
            let destination = segue.destination as! RestaurantInformationViewController
            destination.restaurantdata = selectedrestaurant
            destination.restaurantdataimage = selectedrestaurantimages
        }
    }
}



extension EatOutViewController: UICollectionViewDelegateFlowLayout{
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, sizeForItemAt indexPath: IndexPath) -> CGSize {
        return CGSize(width: 175, height: 175)
    }
}
 
