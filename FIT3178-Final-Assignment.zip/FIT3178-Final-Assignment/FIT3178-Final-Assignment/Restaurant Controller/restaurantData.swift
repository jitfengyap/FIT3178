//
//  restaurantData.swift
//  FIT3178-Final-Assignment
//
//  Created by Jit Yap on 5/5/2023.
//

import UIKit

class RestaurantData: NSObject, Decodable{
    
    // all the information needed to get from the java script.
    var name: String
    var imageURL: String?
    var isclosed: Bool?
    var rating: Float?
    var price: String?
    var phone: String?
    var latitude: Double?
    var longitude: Double?
    var location_address: String? = ""
    var review_count: Int
    
    // the header name for each information to acquire.
    private enum RestaurantInfoKeys: String, CodingKey{
        case name
        case imageURL = "image_url"
        case is_closed
        case rating
        case coordinates
        case price
        case phone
        case location
        case review_count
    }
    
    // since the information is in a {} create a seperate coding key
    private enum CoordinateKeys: String, CodingKey{
        case latitude
        case longitude
    }
    
    private enum LocationKeys: String, CodingKey{
        case address = "display_address"
    }
    
    // steps to acquire information from the javascript in the api.
    required init(from decoder: Decoder) throws {
        let rootContainer = try decoder.container(keyedBy: RestaurantInfoKeys.self)
        
        name = try rootContainer.decode(String.self, forKey: .name)
        imageURL = try rootContainer.decode(String.self, forKey: .imageURL)
        isclosed = try rootContainer.decode(Bool.self, forKey: .is_closed)
        rating = try rootContainer.decode(Float.self, forKey: .rating)
        price = try rootContainer.decode(String.self, forKey: .price)
        phone = try rootContainer.decode(String.self, forKey: .phone)
        review_count = try rootContainer.decode(Int.self, forKey: .review_count)
        
        let coordinateContainer = try rootContainer.nestedContainer(keyedBy: CoordinateKeys.self, forKey: .coordinates)
        
        latitude = try coordinateContainer.decode(Double.self, forKey: .latitude)
        longitude = try coordinateContainer.decode(Double.self, forKey: .longitude)
        
        let locationContainer = try? rootContainer.nestedContainer(keyedBy: LocationKeys.self, forKey: .location)
        
        if let location_name = try locationContainer?.decode([String].self, forKey: .address){
            for name in location_name{
                location_address! += name + " "
            }
        }
            
        
    }
}
