//
//  RestaurantInformationViewController.swift
//  FIT3178-Final-Assignment
//
//  Created by Jit Yap on 23/4/2023.
//

import UIKit

class RestaurantInformationViewController: UIViewController {

    var restaurantdata: RestaurantData?
    var restaurantdataimage: UIImage?
    
    @IBOutlet weak var restaurantimageview: UIImageView!
    
    @IBOutlet weak var restaurantnamelabel: UILabel!
    
    @IBOutlet weak var restaurantpricelabel: UILabel!
    
    @IBOutlet weak var restaurantaddresslabel: UILabel!
    
    @IBOutlet weak var restaurantphonenumber: UILabel!
    
    @IBOutlet weak var restauranttotalreview: UILabel!
    @IBOutlet weak var restaurantreviews: UILabel!
    @IBOutlet weak var restaurantavailability: UILabel!
    
    override func viewDidLoad() {
        super.viewDidLoad()

        restaurantimageview.image = restaurantdataimage
        restaurantnamelabel.text = restaurantdata?.name
        restaurantpricelabel.text = "Average Price: " + (restaurantdata?.price ?? "$")
        restaurantaddresslabel.text = restaurantdata?.location_address
        restaurantreviews.text = "Rating: \(restaurantdata?.rating ?? 0.0)/5"
        restaurantphonenumber.text = "Phone Number: " + (restaurantdata?.phone ?? "not available")
        restauranttotalreview.text = "Total Reviews: \(restaurantdata?.review_count ?? 0)"
        if restaurantdata?.isclosed == false{
            restaurantavailability.text = "This restaurant is currently closed"
        }else{
            restaurantavailability.text = "This restaurant is open now!"
        }
        
        // Do any additional setup after loading the view.
    }
    
    @IBAction func gonowbutton(_ sender: Any) {
        
    }
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        if segue.identifier == "mapsegue"{
            let destination = segue.destination as! AppleMapViewController
            destination.restaurantlocationlatitde = restaurantdata?.latitude
            destination.restaurantlocationlongitude = restaurantdata?.longitude
        }
    }
    
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
