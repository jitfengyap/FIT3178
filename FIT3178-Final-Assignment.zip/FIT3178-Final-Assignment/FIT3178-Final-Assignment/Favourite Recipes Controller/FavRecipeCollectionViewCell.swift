//
//  FavRecipeCollectionViewCell.swift
//  FIT3178-Final-Assignment
//
//  Created by Jit Yap on 11/5/2023.
//

import UIKit

protocol FavRecipeCell: class{
    func delete(cell: FavRecipeCollectionViewCell)
}

class FavRecipeCollectionViewCell: UICollectionViewCell {
    
    weak var delegate: FavRecipeCell?
    
    @IBOutlet weak var FavRecipeImageView: UIImageView!
    @IBOutlet weak var favRecipeTitleLabel: UILabel!
    
    @IBAction func deletebutton(_ sender: Any) {
        delegate?.delete(cell: self)
    }
}
