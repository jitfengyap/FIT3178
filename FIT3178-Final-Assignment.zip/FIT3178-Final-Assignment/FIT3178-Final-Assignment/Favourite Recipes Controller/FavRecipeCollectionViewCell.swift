//
//  FavRecipeCollectionViewCell.swift
//  FIT3178-Final-Assignment
//
//  Created by Jit Yap on 11/5/2023.
//

import UIKit

// protocol to send information on which cell to delete
protocol FavRecipeCell: class{
    func delete(cell: FavRecipeCollectionViewCell)
}

class FavRecipeCollectionViewCell: UICollectionViewCell {
    
    // instantiate favrecipecell delegate to call/use the function in the protocol
    weak var delegate: FavRecipeCell?

    // buttons, label and view for the cell
    @IBOutlet weak var FavRecipeImageView: UIImageView!
    @IBOutlet weak var favRecipeTitleLabel: UILabel!
    
    @IBAction func deletebutton(_ sender: Any) {
        delegate?.delete(cell: self)
    }
}
