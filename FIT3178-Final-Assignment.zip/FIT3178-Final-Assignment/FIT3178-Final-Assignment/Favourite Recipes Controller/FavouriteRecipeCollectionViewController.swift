//
//  FavouriteRecipeCollectionViewController.swift
//  FIT3178-Final-Assignment
//
//  Created by Jit Yap on 11/5/2023.
//

import UIKit

private let reuseIdentifier = "Cell"

class FavouriteRecipeCollectionViewController: UICollectionViewController, DatabaseListener, UICollectionViewDelegateFlowLayout {
    
    let RECIPE_CELL = "FavouriteRecipeCell"
    let SECTION_RECIPE = 0
    
    var selectedRecipe: Recipe?
    var selectedRecipeImage: UIImage?
    
    var imageisDownloading = false
    var imageShown = true
    
    var allRecipe: [Recipe] = []
    var allRecipeImage: [UIImage?] = []
    weak var databaseController: DatabaseProtocol?
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        let appDelegate = (UIApplication.shared.delegate as? AppDelegate)
        databaseController = appDelegate?.databaseController
        // Uncomment the following line to preserve selection between presentations
        // self.clearsSelectionOnViewWillAppear = false

        // Register cell classes
        self.collectionView!.register(UICollectionViewCell.self, forCellWithReuseIdentifier: reuseIdentifier)

        collectionView.collectionViewLayout = UICollectionViewFlowLayout()
        // Do any additional setup after loading the view.
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        databaseController?.addListener(listener: self)
    }
    
    override func viewWillDisappear(_ animated: Bool) {
        super.viewWillDisappear(animated)
        databaseController?.removeListener(listener: self)
    }
    
    func onRecipeListChange(recipeList: [Recipe]) {
        allRecipe = recipeList
        allRecipeImage = []
        for _ in allRecipe{
            allRecipeImage.append(nil)
        }
        collectionView.reloadData()
    }

    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, sizeForItemAt indexPath: IndexPath) -> CGSize {
        return CGSize(width: 190, height: 200)
    }
    
    // MARK: UICollectionViewDataSource

    override func numberOfSections(in collectionView: UICollectionView) -> Int {
        // #warning Incomplete implementation, return the number of sections
        return 1
    }


    override func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        // #warning Incomplete implementation, return the number of items
        return allRecipe.count
    }

    override func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: RECIPE_CELL, for: indexPath) as! FavRecipeCollectionViewCell
        
        let recipe = allRecipe[indexPath.row]
        cell.favRecipeTitleLabel.text = recipe.title
        cell.delegate = self
        
        cell.FavRecipeImageView?.image = allRecipeImage[indexPath.row]
        if cell.FavRecipeImageView?.image == nil{
            imageisDownloading = false
        }
        
        if let image = allRecipeImage[indexPath.row]{
            cell.FavRecipeImageView?.image = image
        }else if imageisDownloading == false, let imageURL = recipe.imageURL{
            let requestURL = URL(string: imageURL)
            if let requestURL{
                Task{
                    print("Downloading image: " + imageURL)
                    imageisDownloading = true
                    do{
                        let (data, response) = try await URLSession.shared.data(from: requestURL)
                        guard let httpResponse = response as? HTTPURLResponse,
                              httpResponse.statusCode == 200 else {
                            imageisDownloading = false
                            throw RecipeDetailError.invalidServerResponse
                        }
                        if let image = UIImage(data: data){
                            print("Image downloaded successfully: " + imageURL)
                            let croppedImage = cropimage(image: image)
                            allRecipeImage[indexPath.row] = croppedImage
                            await MainActor.run{
                                collectionView.reloadItems(at:[indexPath])
                            }
                        }
                        else{
                            print("Image Invalid: " + imageURL)
                            imageisDownloading = false
                        }
                    }
                    catch{
                        print(error.localizedDescription)
                    }
                }
            }
            else{
                print("Error: URL not valid: " + imageURL)
            }
        }
        
        return cell
    }
    
    override func collectionView(_ collectionView: UICollectionView, shouldSelectItemAt indexPath: IndexPath) -> Bool {
        return true
    }
    
    override func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
        selectedRecipe = allRecipe[indexPath.row]
        selectedRecipeImage = allRecipeImage[indexPath.row]
        performSegue(withIdentifier: "favrecipetableviewsegue", sender: self)
    }

    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        if segue.identifier == "favrecipetableviewsegue"{
            let destination = segue.destination as! FavouriteRecipeTableViewController
            destination.recipeinfo = selectedRecipe
            destination.recipedownloadedimage = selectedRecipeImage
        }
    }
    
    func cropimage(image: UIImage) -> UIImage?{
        let sideLength = min(image.size.width, image.size.height)
        let originX = (image.size.width - sideLength) / 2
        let originY = (image.size.height - sideLength) / 2
        let cropRect = CGRect(x:originX, y: originY, width: sideLength, height:sideLength)
        guard let cgImage = image.cgImage?.cropping(to: cropRect)else{
            return nil
        }
        return UIImage(cgImage: cgImage)
    }
    // MARK: UICollectionViewDelegate

}

extension FavouriteRecipeCollectionViewController: FavRecipeCell{
    func delete(cell: FavRecipeCollectionViewCell) {
        if let indexPath = collectionView?.indexPath(for: cell){
            self.databaseController?.removeRecipe(recipe: allRecipe[indexPath.row])
        }
        collectionView.reloadData()
    }
}
