//
//  FavouriteRecipeTableViewController.swift
//  FIT3178-Final-Assignment
//
//  Created by Jit Yap on 17/5/2023.
//

import UIKit

class FavouriteRecipeTableViewController: UITableViewController {
    
    let SECTION_NUTRIENTS = 0
    let SECTION_INGREDIENTS = 1
    let SECTION_INSTUCTIONS = 2
    
    var recipeinfo: Recipe?
    var recipedownloadedimage: UIImage?
    
    var caloriesAmount: String?
    var proteinAmount: String?
    var carbsAmount: String?
    var fatsAmount: String?

    override func viewDidLoad() {
        super.viewDidLoad()
        // Uncomment the following line to preserve selection between presentations
        // self.clearsSelectionOnViewWillAppear = false

        // Uncomment the following line to display an Edit button in the navigation bar for this view controller.
        // self.navigationItem.rightBarButtonItem = self.editButtonItem
        Task{
            URLSession.shared.invalidateAndCancel()
            await get_nutrition()
        }
    }

    // get the nutritional information from spoonacular api base on nutriondata codable. refresh everytime data is being loaded.
    func get_nutrition()async{
        var components = URLComponents()
        components.host = "api.spoonacular.com"
        components.path = "/recipes/" + String(recipeinfo!.id) + "/nutritionWidget.json"
        components.scheme = "https"
        components.queryItems = [URLQueryItem]()
        components.queryItems?.append(URLQueryItem(name: "apiKey", value: "c84f3713b66a41bd89bc0057abb44ecf"))
        
        guard let requestURL = components.url else{
            print("Invalid URL.")
            return
        }
        
        let urlRequest = URLRequest(url:requestURL)
        
        do{
            let(data, response) = try await URLSession.shared.data(for: urlRequest)
            do{
                let decoder = JSONDecoder()
                let nutritionData = try decoder.decode(NutritionData.self, from: data)
                proteinAmount = "Protein: " + nutritionData.protein
                caloriesAmount = "Calorie: " + nutritionData.calories
                fatsAmount = "Fats: " + nutritionData.fat
                carbsAmount = "Carbs: " + nutritionData.carbs
                tableView.reloadData()
                }
        }catch let error{
            print(error)
        }

    }
    
    // MARK: - Table view data source
    //return number of sections in the table
    override func numberOfSections(in tableView: UITableView) -> Int {
        // #warning Incomplete implementation, return the number of sections
        return 3
    }

    // return the number of rows in each section
    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        // #warning Incomplete implementation, return the number of rows
        return 1
    }

    // show different data in each cell.
    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        if indexPath.section == SECTION_NUTRIENTS{
            let recipenutrientcell = tableView.dequeueReusableCell(withIdentifier: "FavouriteRecipeCell", for: indexPath) as! FavouriteRecipeTableViewCell
            recipenutrientcell.FavouriteRecipeCalories.text = carbsAmount
            recipenutrientcell.FavouriteRecipeNameLabel.text = recipeinfo?.title
            recipenutrientcell.FavouriteRecipeCarbs.text = caloriesAmount
            recipenutrientcell.FavouriteRecipeProtein.text = proteinAmount
            recipenutrientcell.FavouriteRecipeFats.text = fatsAmount
            recipenutrientcell.FavouriteRecipeImage.image = recipedownloadedimage
            
            return recipenutrientcell
        }
        else if indexPath.section == SECTION_INGREDIENTS{
            let recipeingredientcell = tableView.dequeueReusableCell(withIdentifier: "FavouriteRecipeIngredientcell", for: indexPath)
            var ingredientcontent = recipeingredientcell.defaultContentConfiguration()
            ingredientcontent.text = "Recipe Ingredients"
            ingredientcontent.secondaryText = recipeinfo?.allingredients
            recipeingredientcell.contentConfiguration = ingredientcontent
            
            return recipeingredientcell
        }
        else{
            let recipeinstructioncell = tableView.dequeueReusableCell(withIdentifier: "FavouriteRecipeInstructionCell", for: indexPath)
            var instructioncontent = recipeinstructioncell.defaultContentConfiguration()
            instructioncontent.text = "Recipe Instruction"
            instructioncontent.secondaryText = recipeinfo?.instruction
            recipeinstructioncell.contentConfiguration = instructioncontent
            
            return recipeinstructioncell
        }
    }

}
