//
//  FavouriteRecipeTableViewCell.swift
//  FIT3178-Final-Assignment
//
//  Created by Jit Yap on 17/5/2023.
//

import UIKit

class FavouriteRecipeTableViewCell: UITableViewCell {

    @IBOutlet weak var FavouriteRecipeNameLabel: UILabel!
    
    @IBOutlet weak var FavouriteRecipeImage: UIImageView!
    
    @IBOutlet weak var FavouriteRecipeCalories: UILabel!
    
    @IBOutlet weak var FavouriteRecipeProtein: UILabel!
    
    @IBOutlet weak var FavouriteRecipeCarbs: UILabel!
    
    @IBOutlet weak var FavouriteRecipeFats: UILabel!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
