//
//  Nutritions+CoreDataProperties.swift
//  FIT3178-Final-Assignment
//
//  Created by Jit Yap on 17/5/2023.
//
//

import Foundation
import CoreData


extension Nutritions {

    @nonobjc public class func fetchRequest() -> NSFetchRequest<Nutritions> {
        return NSFetchRequest<Nutritions>(entityName: "Nutritions")
    }

    @NSManaged public var calorie: String?
    @NSManaged public var carbs: String?
    @NSManaged public var protein: String?
    @NSManaged public var fats: String?

}

extension Nutritions : Identifiable {

}
