//
//  Recipe+CoreDataProperties.swift
//  FIT3178-Final-Assignment
//
//  Created by Jit Yap on 11/5/2023.
//
//

import Foundation
import CoreData


extension Recipe {

    @nonobjc public class func fetchRequest() -> NSFetchRequest<Recipe> {
        return NSFetchRequest<Recipe>(entityName: "Recipe")
    }

    @NSManaged public var allingredients: String?
    @NSManaged public var id: Int64
    @NSManaged public var imageURL: String?
    @NSManaged public var instruction: String?
    @NSManaged public var title: String?

}

extension Recipe : Identifiable {

}
