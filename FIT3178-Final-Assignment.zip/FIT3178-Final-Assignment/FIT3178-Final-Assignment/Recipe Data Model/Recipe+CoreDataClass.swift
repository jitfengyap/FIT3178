//
//  Recipe+CoreDataClass.swift
//  FIT3178-Final-Assignment
//
//  Created by Jit Yap on 11/5/2023.
//
//

import Foundation
import CoreData

@objc(Recipe)
public class Recipe: NSManagedObject {

}
