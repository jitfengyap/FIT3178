//
//  Nutritions+CoreDataClass.swift
//  FIT3178-Final-Assignment
//
//  Created by Jit Yap on 17/5/2023.
//
//

import Foundation
import CoreData

@objc(Nutritions)
public class Nutritions: NSManagedObject {

}
