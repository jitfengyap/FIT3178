//
//  DatabaseProtocol.swift
//  FIT3178-Final-Assignment
//
//  Created by Jit Yap on 10/5/2023.
//

import Foundation

enum DatabaseChange{
    case add
    case remove
    case update
}

enum ListenerType{
    case nutrition
    case recipe
    case all
}

protocol DatabaseListener: AnyObject{
    var listenerType: ListenerType {get set}
    func onRecipeListChange(change: DatabaseChange, recipeList: [Recipe])
    func onnutritionChange(change: DatabaseChange, nutritions: [Nutritions])
}


protocol DatabaseProtocol: AnyObject{
    func cleanup()
    func addListener(listener: DatabaseListener)
    func removeListener(listener: DatabaseListener)
    
    func addRecipe(recipeData: RecipeData) -> Recipe
    func removeRecipe(recipe: Recipe)
    
    func addnutrition(nutritionData: NutritionData) -> Nutritions
    func removenutrition(nutritions: Nutritions)
}
