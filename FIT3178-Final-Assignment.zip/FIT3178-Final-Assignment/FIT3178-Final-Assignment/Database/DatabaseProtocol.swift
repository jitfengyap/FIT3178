//
//  DatabaseProtocol.swift
//  FIT3178-Final-Assignment
//
//  Created by Jit Yap on 10/5/2023.
//

import Foundation

protocol DatabaseListener: AnyObject{
    func onRecipeListChange(recipeList: [Recipe])
}

protocol DatabaseProtocol: AnyObject{
    func cleanup()
    func addListener(listener: DatabaseListener)
    func removeListener(listener: DatabaseListener)
    
    func addRecipe(recipeData: RecipeData) -> Recipe
    func removeRecipe(recipe: Recipe)
    
}
