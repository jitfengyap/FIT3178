//
//  CoreDataController.swift
//  FIT3178-Final-Assignment
//
//  Created by Jit Yap on 10/5/2023.
//

import UIKit
import CoreData

class CoreDataController: NSObject, NSFetchedResultsControllerDelegate, DatabaseProtocol{

    
    
    var listeners = MulticastDelegate<DatabaseListener>()
    var persistentContainer: NSPersistentContainer
    var allRecipeFetchResultsController: NSFetchedResultsController<Recipe>?
    var allNutrientsFetchResultsController: NSFetchedResultsController<Nutritions>?
    
    override init() {
        persistentContainer = NSPersistentContainer(name:"RecipeDataModel")
        persistentContainer.loadPersistentStores(){(description,error) in
            if let error{
                fatalError("Failed to load Core Data stack with error: \(error)")
            }
        }
        super.init()
    }
    
    func fetchAllRecipes() -> [Recipe]{
        if allRecipeFetchResultsController == nil{
            let fetchRequest: NSFetchRequest<Recipe> = Recipe.fetchRequest()
            let nameSortDescriptor = NSSortDescriptor(key:"title", ascending: true)
            fetchRequest.sortDescriptors = [nameSortDescriptor]
            
            allRecipeFetchResultsController = NSFetchedResultsController<Recipe>(fetchRequest: fetchRequest, managedObjectContext: persistentContainer.viewContext, sectionNameKeyPath: nil, cacheName: nil)
            
            allRecipeFetchResultsController?.delegate = self
            do{
                try allRecipeFetchResultsController?.performFetch()
            }catch {
                print("Fetch Request failed: \(error)")
            }
        }
        if let recipes = allRecipeFetchResultsController?.fetchedObjects{
            return recipes
        }
        return [Recipe]()
    }

    func fetchAllNutritions() -> [Nutritions]{
        if allNutrientsFetchResultsController == nil{
            let fetchRequest: NSFetchRequest<Nutritions> = Nutritions.fetchRequest()
            let nameSortDescriptor = NSSortDescriptor(key: "calorie", ascending: true)
            fetchRequest.sortDescriptors = [nameSortDescriptor]
            
            allNutrientsFetchResultsController = NSFetchedResultsController<Nutritions>(fetchRequest: fetchRequest, managedObjectContext: persistentContainer.viewContext, sectionNameKeyPath: nil, cacheName: nil)
            
            allNutrientsFetchResultsController?.delegate = self
            do{
                try allNutrientsFetchResultsController?.performFetch()
            }catch{
                print("Fetch Request failed: \(error)")
            }
        }
        if let nutritions = allNutrientsFetchResultsController?.fetchedObjects{
            return nutritions
        }
        return [Nutritions]()
    }
    
    func cleanup() {
        if persistentContainer.viewContext.hasChanges{
            do{
                try persistentContainer.viewContext.save()
            }catch {
                fatalError("Failed to save data to Core Data wth error \(error)")
            }
        }
        allRecipeFetchResultsController = nil
    }
    
    func addListener(listener: DatabaseListener) {
        listeners.addDelegate(listener)
        
        if listener.listenerType == .recipe || listener.listenerType == .all{
            listener.onRecipeListChange(change: .update, recipeList: fetchAllRecipes())
        }
        else if listener.listenerType == .nutrition || listener.listenerType == .all{
            listener.onnutritionChange(change: .update, nutritions: fetchAllNutritions())
        }
//        listener.onRecipeListChange(recipeList: fetchAllRecipes())
    }
    
    func removeListener(listener: DatabaseListener) {
        listeners.removeDelegate(listener)
    }
    
    func addRecipe(recipeData: RecipeData) -> Recipe {
        let recipe = NSEntityDescription.insertNewObject(forEntityName: "Recipe", into: persistentContainer.viewContext) as! Recipe
        recipe.id = Int64(recipeData.id)
        recipe.allingredients = recipeData.allingredients
        recipe.imageURL = recipeData.imageURL
        recipe.instruction = recipeData.instruction
        recipe.title = recipeData.title
        return recipe
    }
    
    func removeRecipe(recipe: Recipe) {
        persistentContainer.viewContext.delete(recipe)
    }
    
    func controllerDidChangeContent(_ controller: NSFetchedResultsController<NSFetchRequestResult>) {
        if controller == allRecipeFetchResultsController{
            listeners.invoke(){ listener in
                if listener.listenerType == .recipe || listener.listenerType == .all{
                    listener.onRecipeListChange(change:.update, recipeList: fetchAllRecipes())
                }
            }
        }else if controller == allNutrientsFetchResultsController {
            listeners.invoke(){listener in
                if listener.listenerType == .nutrition || listener.listenerType == .all{
                    listener.onnutritionChange(change: .update, nutritions: fetchAllNutritions())
                }
            }
        }
    }
    
    func addnutrition(nutritionData: NutritionData) -> Nutritions {
        let nutritioninfo = NSEntityDescription.insertNewObject(forEntityName: "Nutritions", into: persistentContainer.viewContext) as! Nutritions
        nutritioninfo.calorie = nutritionData.calories
        nutritioninfo.carbs = nutritionData.carbs
        nutritioninfo.protein = nutritionData.protein
        nutritioninfo.fats = nutritionData.fat
        return nutritioninfo
    }
    
    func removenutrition(nutritions: Nutritions) {
        persistentContainer.viewContext.delete(nutritions)
    }

}
