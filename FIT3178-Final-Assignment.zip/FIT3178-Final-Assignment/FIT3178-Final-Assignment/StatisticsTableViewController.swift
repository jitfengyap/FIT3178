//
//  StatisticsTableViewController.swift
//  FIT3178-Final-Assignment
//
//  Created by Jit Yap on 21/5/2023.
//

import UIKit

class StatisticsTableViewController: UITableViewController, DatabaseListener {
    
    let CALORIE_CELL = "caloriecell"
    let CARB_CELL = "carbcell"
    let PROTEIN_CELL = "proteincell"
    let fats_CELL = "fatcell"
    
    let SECTION_CALORIE = 0
    let SECTION_CARBS = 1
    let SECTION_PROTEIN = 2
    let SECTION_FATS = 3
    
    var total_calorie = 0
    var total_carbs = 0
    var total_protein = 0
    var total_fats = 0
    
    var listenerType: ListenerType = .nutrition
    
    var allNutritions: [Nutritions] = []
    weak var databaseController: DatabaseProtocol?
    

    override func viewDidLoad() {
        super.viewDidLoad()

        let appDelegate = (UIApplication.shared.delegate as? AppDelegate)
        databaseController = appDelegate?.databaseController
        // Uncomment the following line to preserve selection between presentations
        // self.clearsSelectionOnViewWillAppear = false

        // Uncomment the following line to display an Edit button in the navigation bar for this view controller.
        // self.navigationItem.rightBarButtonItem = self.editButtonItem
    }
    
    override func tableView(_ tableView: UITableView, titleForHeaderInSection section: Int) -> String? {
        if section == SECTION_CALORIE{
            return "Total calorie"
        }else if section == SECTION_PROTEIN{
            return "Total protein"
        }else if section == SECTION_CARBS{
            return "Total carbs"
        }else if section == SECTION_FATS{
            return "Total fats"
        }else{
            return ""
        }
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        databaseController?.addListener(listener: self)
    }
    
    override func viewWillDisappear(_ animated: Bool) {
        super.viewWillDisappear(animated)
        databaseController?.removeListener(listener: self)
    }
    
    func onRecipeListChange(change: DatabaseChange, recipeList: [Recipe]) {
        
    }
    
    func onnutritionChange(change: DatabaseChange, nutritions: [Nutritions]) {
        allNutritions = nutritions
        tableView.reloadData()
    }

    // MARK: - Table view data source

    override func numberOfSections(in tableView: UITableView) -> Int {
        // #warning Incomplete implementation, return the number of sections
        return 4
    }

    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        // #warning Incomplete implementation, return the number of rows
        return allNutritions.count
    }

    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let row_recipe = allNutritions[indexPath.row]
        
        if indexPath.section == SECTION_CALORIE{
            let caloriecell = tableView.dequeueReusableCell(withIdentifier: CALORIE_CELL, for: indexPath)
            var caloriecontent = caloriecell.defaultContentConfiguration()
            caloriecontent.text = row_recipe.calorie! + " calorie"
            caloriecell.contentConfiguration = caloriecontent
            let str = row_recipe.calorie
            total_calorie += getNumbers(from: row_recipe.calorie!)[0]
//            print(total_calorie)
            
            return caloriecell
        }
        else if indexPath.section == SECTION_CARBS{
            let carbscell = tableView.dequeueReusableCell(withIdentifier: CARB_CELL, for: indexPath)
            var carbcontent = carbscell.defaultContentConfiguration()
            carbcontent.text = row_recipe.carbs
            carbscell.contentConfiguration = carbcontent
            total_carbs += getNumbers(from: row_recipe.carbs!)[0]
//            print(total_carbs)
            
            return carbscell
        }
        else if indexPath.section == SECTION_FATS{
            let fatscell = tableView.dequeueReusableCell(withIdentifier: fats_CELL, for: indexPath)
            var fatcontent = fatscell.defaultContentConfiguration()
            fatcontent.text = row_recipe.fats
            fatscell.contentConfiguration = fatcontent
            total_fats += getNumbers(from: row_recipe.fats!)[0]
//            print(total_fats)
            
            return fatscell
        }
        else{
            let proteincell = tableView.dequeueReusableCell(withIdentifier: PROTEIN_CELL, for: indexPath)
            var proteincontent = proteincell.defaultContentConfiguration()
            proteincontent.text = row_recipe.protein
            proteincell.contentConfiguration = proteincontent
            total_protein += getNumbers(from: row_recipe.protein!)[0]
//            print(total_protein)
            
            return proteincell
        }
//        else if indexPath.section == SECTION_PROTEIN{
//            let proteincell = tableView.dequeueReusableCell(withIdentifier: PROTEIN_CELL, for: indexPath)
//            var proteincontent = proteincell.defaultContentConfiguration()
//            proteincell.text = row_recipe.protein
//            proteincell.contentConfiguration = proteincontent
//
//            return proteincell
//        }
    }
    
    func getNumbers(from text: String) -> [Int]{
        let regex = try! NSRegularExpression(pattern: "\\d+")
        let matches = regex.matches(in: text, range: NSRange(text.startIndex..., in: text))
        
        return matches.map{ match in
            Int(String(text[Range(match.range, in: text)!]))!
        }
    }
    
    
    override func tableView(_ tableView: UITableView, canEditRowAt indexPath: IndexPath) -> Bool {
        if indexPath.section == SECTION_CALORIE {
            return true
        }
        return false
    }
    
    // Override to support editing the table view.
    override func tableView(_ tableView: UITableView, commit editingStyle: UITableViewCell.EditingStyle, forRowAt indexPath: IndexPath) {
        if editingStyle == .delete && indexPath.section == SECTION_CALORIE{
            self.databaseController?.removenutrition(nutritions: allNutritions[indexPath.row])
            tableView.reloadData()
        }
    }

    /*
    // Override to support rearranging the table view.
    override func tableView(_ tableView: UITableView, moveRowAt fromIndexPath: IndexPath, to: IndexPath) {

    }
    */

    /*
    // Override to support conditional rearranging of the table view.
    override func tableView(_ tableView: UITableView, canMoveRowAt indexPath: IndexPath) -> Bool {
        // Return false if you do not want the item to be re-orderable.
        return true
    }
    */

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
