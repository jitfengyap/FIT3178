//
//  RecipeInformationTableViewCell.swift
//  FIT3178-Final-Assignment
//
//  Created by Jit Yap on 30/4/2023.
//

import UIKit

class RecipeInformationTableViewCell: UITableViewCell {

    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    // customized table with new labels and images to display nutritional inforamtion about the recipe
    @IBOutlet weak var Foodtitle: UILabel!
    @IBOutlet weak var Calorietitle: UILabel!
    @IBOutlet weak var Proteintitle: UILabel!
    @IBOutlet weak var Carbstitle: UILabel!
    @IBOutlet weak var Fatstitle: UILabel!
    @IBOutlet weak var recipeimageview: UIImageView!
    
    @IBAction func Favoritebutton(_ sender: Any) {
    }
    
    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }
}
