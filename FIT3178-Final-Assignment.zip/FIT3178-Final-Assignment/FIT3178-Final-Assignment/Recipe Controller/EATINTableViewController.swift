//
//  EATINTableViewController.swift
//  FIT3178-Final-Assignment
//
//  Created by Jit Yap on 30/4/2023.
//

import UIKit

class EATINTableViewController: UITableViewController {
    //need to conform to database protocol
    
    let SECTION_NUTRIENTS = 0
    let SECTION_INGREDIENTS = 1
    let SECTION_INSTUCTIONS = 2
    let SECTION_BUTTON = 3
    
    var recipeinfo: RecipeData?
    var recipedownloadedimage: UIImage?
    
    var nutritionsinfo: NutritionData?
    var caloriesAmount: String?
    var proteinAmount: String?
    var carbsAmount: String?
    var fatsAmount: String?
    weak var databaseController: DatabaseProtocol?

    override func viewDidLoad() {
        super.viewDidLoad()
        
        let appDelegate = (UIApplication.shared.delegate as? AppDelegate)
        databaseController = appDelegate?.databaseController

        Task{
            URLSession.shared.invalidateAndCancel()
            await get_nutrition()
        }
    }


    // return total number of section in the collection view.
    override func numberOfSections(in tableView: UITableView) -> Int {
        return 4
    }

    // return total row that are being displayed for each section.
    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return 1
    }

    // get the nutritional information about the recipe from spoonacular api based on the selected recipe id. javascript provided by the api will be broken down using nutrition data.
    func get_nutrition()async{
        var components = URLComponents()
        components.host = "api.spoonacular.com"
        components.path = "/recipes/" + String(recipeinfo!.id) + "/nutritionWidget.json"
        components.scheme = "https"
        components.queryItems = [URLQueryItem]()
        components.queryItems?.append(URLQueryItem(name: "apiKey", value: "c84f3713b66a41bd89bc0057abb44ecf"))
        
        guard let requestURL = components.url else{
            print("Invalid URL.")
            return
        }
        
        let urlRequest = URLRequest(url:requestURL)
        
        do{
            let(data, response) = try await URLSession.shared.data(for: urlRequest)
            do{
                let decoder = JSONDecoder()
                let nutritionData = try decoder.decode(NutritionData.self, from: data)
                nutritionsinfo = nutritionData
                proteinAmount = "Protein: " + nutritionData.protein
                caloriesAmount = "Calorie: " + nutritionData.calories
                fatsAmount = "Fats: " + nutritionData.fat
                carbsAmount = "Carbs: " + nutritionData.carbs
                tableView.reloadData()
                }
        }catch let error{
            print(error)
        }

    }
    
    // store the recipe into core data
    @IBAction func FavoriteButton(_ sender: Any) {
        //save the data here
        guard let recipe = recipeinfo else{
            return
        }
        let _ = databaseController?.addRecipe(recipeData: recipe)
    }
    
    // display the information of the recipe for every section
    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        if indexPath.section == SECTION_NUTRIENTS{
            let recipenutrientcell = tableView.dequeueReusableCell(withIdentifier: "recipenutrientscell", for: indexPath) as! RecipeInformationTableViewCell
            recipenutrientcell.Carbstitle.text = carbsAmount
            recipenutrientcell.Foodtitle.text = recipeinfo?.title
            recipenutrientcell.Calorietitle.text = caloriesAmount
            recipenutrientcell.Proteintitle.text = proteinAmount
            recipenutrientcell.Fatstitle.text = fatsAmount
            recipenutrientcell.recipeimageview.image = recipedownloadedimage
            
            return recipenutrientcell
        }
        else if indexPath.section == SECTION_INGREDIENTS{
            let recipeingredientcell = tableView.dequeueReusableCell(withIdentifier: "recipeingredientscell", for: indexPath)
            var ingredientcontent = recipeingredientcell.defaultContentConfiguration()
            ingredientcontent.text = "Recipe Ingredients"
            ingredientcontent.secondaryText = recipeinfo?.allingredients
            recipeingredientcell.contentConfiguration = ingredientcontent
            
            return recipeingredientcell
        }
        else if indexPath.section == SECTION_INSTUCTIONS{
            let recipeinstructioncell = tableView.dequeueReusableCell(withIdentifier: "recipeinstructioncell", for: indexPath)
            var instructioncontent = recipeinstructioncell.defaultContentConfiguration()
            instructioncontent.text = "Recipe Instruction"
            instructioncontent.secondaryText = recipeinfo?.instruction
            recipeinstructioncell.contentConfiguration = instructioncontent
            
            return recipeinstructioncell
        }
        else{
            let buttoncell = tableView.dequeueReusableCell(withIdentifier: "addtotrackerbuttoncell", for: indexPath)
            
            return buttoncell
        }
    }

    // if the last row is being selected then add the nutrional data into nutrition core data.
    override func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        if indexPath.section == SECTION_BUTTON {
            guard let nutrition = nutritionsinfo else{
                return
            }
            let _ = databaseController?.addnutrition(nutritionData: nutrition)
        }
    }
    
}
