//
//  RecipeCollectionViewCell.swift
//  FIT3178-Final-Assignment
//
//  Created by Jit Yap on 28/4/2023.
//

import UIKit

class RecipeCollectionViewCell: UICollectionViewCell {
    
    var receivedrecipeimage: UIImage?
    var imageisDownloading = false
    var imageShown = true
    
    // recipe label and images to display in each recipe collection view cell.
    @IBOutlet weak var recipeImage: UIImageView!
    @IBOutlet weak var recipetitle: UILabel!
    
    func setupdetails(with recipe: RecipeData){
        recipetitle.text = recipe.title
    
        recipeImage?.image = nil
    }

    
}
