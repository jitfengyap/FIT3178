//
//  RecipeData.swift
//  FIT3178-Final-Assignment
//
//  Created by Jit Yap on 26/4/2023.
//

import UIKit

class RecipeData: NSObject, Decodable{
    
    var id: Int
    var title: String
    var instruction: String?
    var allingredients: String? = ""
    var imageURL: String?
    
    // header name for each information needed
    private enum RecipeKeys: String, CodingKey{
        case id
        case title
        case image
        case instructions
        case ingredients = "extendedIngredients"
    }
    
    // since the stored data is in a list we will need to use decodable.
    struct IngredientKey: Decodable{
        var name: String
        var amount: Float
        var unit: String
        var originalName: String
    }
    
    // steps taken to acquire information from javascript given by spoonacular.
    required init(from decoder: Decoder) throws {
        
        let rootContainer = try decoder.container(keyedBy: RecipeKeys.self)
        
        id = try rootContainer.decode(Int.self, forKey: .id)
        title = try rootContainer.decode(String.self, forKey: .title)
        instruction = try rootContainer.decode(String.self, forKey: .instructions)
        imageURL = try? rootContainer.decode(String.self, forKey: .image)
        
        if let ingredientsitems = try? rootContainer.decode([IngredientKey].self, forKey: .ingredients){
            var count = 1
            for ingredient in ingredientsitems{
                allingredients! += String(count) + ". " + ingredient.originalName + "\n"
                count+=1
            }
        }
    }
    
}
