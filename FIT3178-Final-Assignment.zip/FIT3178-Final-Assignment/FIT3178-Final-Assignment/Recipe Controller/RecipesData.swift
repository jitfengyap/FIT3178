//
//  RecipesData.swift
//  FIT3178-Final-Assignment
//
//  Created by Jit Yap on 26/4/2023.
//

import UIKit

class RecipesData: NSObject, Decodable{
    
    var recipes: [RecipeData]?

    private enum CodingKeys: String, CodingKey{
        case recipes
    }
}
