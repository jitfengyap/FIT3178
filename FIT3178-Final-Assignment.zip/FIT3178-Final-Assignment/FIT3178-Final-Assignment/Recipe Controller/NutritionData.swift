//
//  NutritionData.swift
//  FIT3178-Final-Assignment
//
//  Created by Jit Yap on 28/4/2023.
//

import UIKit

class NutritionData: NSObject, Decodable {

    // the calorie data needed from spoonacular
    var calories: String
    var carbs: String
    var fat: String
    var protein: String

    // header name for the information needed from javascript
    private enum CodingKeys: String, CodingKey{
        case calories
        case carbs
        case fat
        case protein
    }
    
    // steps taken to dissect the javascript given by spoonacular api.
    required init(from decoder: Decoder) throws {
        
        let rootContainer = try decoder.container(keyedBy: CodingKeys.self)
        
        calories = try rootContainer.decode(String.self, forKey: .calories)
        fat = try rootContainer.decode(String.self, forKey: .fat)
        protein = try rootContainer.decode(String.self, forKey: .protein)
        carbs = try rootContainer.decode(String.self, forKey: .carbs)
    }
}
