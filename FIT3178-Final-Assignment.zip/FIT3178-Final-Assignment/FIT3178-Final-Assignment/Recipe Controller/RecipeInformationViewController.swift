//
//  RecipeInformationViewController.swift
//  FIT3178-Final-Assignment
//
//  Created by Jit Yap on 23/4/2023.
//

import UIKit

class RecipeInformationViewController: UIViewController{

    
    
    @IBOutlet weak var recipeimage: UIImageView!
    @IBOutlet weak var Recipename: UILabel!
    
    @IBOutlet weak var proteincount: UILabel!
    @IBOutlet weak var fatcount: UILabel!
    @IBOutlet weak var carbcount: UILabel!
    @IBOutlet weak var Calorietext: UILabel!
    
    @IBOutlet weak var nutritionalinformation: UILabel!
    
    let nutritionURL = "https://api.spoonacular.com/recipes/1003464/nutritionWidget.json?apiKey=c84f3713b66a41bd89bc0057abb44ecf"
    
    var recipeinfo: RecipeData?
    var recipedownloadedimage: UIImage?

    override func viewDidLoad() {
        super.viewDidLoad()

        Recipename.text = recipeinfo?.title
        recipeimage.image = recipedownloadedimage
        // Do any additional setup after loading the view.
        Task{
            URLSession.shared.invalidateAndCancel()
            await get_nutrition()
        }
    }
    
    func get_nutrition()async{
        var components = URLComponents()
        components.host = "api.spoonacular.com"
        components.path = "/recipes/" + String(recipeinfo!.id) + "/nutritionWidget.json"
        components.scheme = "https"
        components.queryItems = [URLQueryItem]()
        components.queryItems?.append(URLQueryItem(name: "apiKey", value: "c84f3713b66a41bd89bc0057abb44ecf"))
        
        guard let requestURL = components.url else{
            print("Invalid URL.")
            return
        }
        
        let urlRequest = URLRequest(url:requestURL)
        
        do{
            let(data, response) = try await URLSession.shared.data(for: urlRequest)
            
            do{
                let decoder = JSONDecoder()
                let nutritionData = try decoder.decode(NutritionData.self, from: data)
                proteincount.text = "Protein: " + nutritionData.protein
                Calorietext.text = "Calorie: " + nutritionData.calories
                fatcount.text = "Fats: " + nutritionData.fat
                carbcount.text = "Carbs: " + nutritionData.carbs

                }
        }catch let error{
            print(error)
        }
        
        
    }
    
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
