//
//  EatInCollectionViewController.swift
//  FIT3178-Final-Assignment
//
//  Created by Jit Yap on 23/4/2023.
//

import UIKit

protocol SelectedRecipeDelegate: AnyObject{
    func selectrecipe(recipe: RecipeData,recipeexistingimage: UIImage)
}

private let reuseIdentifier = "Cell"

enum RecipeDetailError: Error{
    case invalidServerResponse
    case invalidShowURL
    case invalidRecipeImageURL
}

class EatInCollectionViewController: UICollectionViewController, UICollectionViewDelegateFlowLayout {

    var receivedrecipeimage: UIImage?
    var imageisDownloading = false
    var imageShown = true
    var selectedrecipe: RecipeData?
    var selectedrecipeimage: UIImage?
    
    weak var delegate: (SelectedRecipeDelegate)?
    
    let request_string = "https://api.spoonacular.com/recipes/random?apiKey=c84f3713b66a41bd89bc0057abb44ecf&number=20"
    
    var newrecipe = [RecipeData]()
    var recipeimages = [UIImage?]()
    var indicator = UIActivityIndicatorView()
    
    let SeguetoRecipeInformationName = "eatintorecipeinfosegue" //delete later
    let SEGUETORECIPEINFORMATIONTABLE = "eatintableviewsegue"

    // load indiacator screen and get all the recipe randomly from spoonacular api.
    override func viewDidLoad() {
        super.viewDidLoad()

        // Uncomment the following line to preserve selection between presentations
        // self.clearsSelectionOnViewWillAppear = false
        
        // Register cell classes
        self.collectionView!.register(UICollectionViewCell.self, forCellWithReuseIdentifier: reuseIdentifier)
        
        //Add a loading indicator view
        indicator.style = UIActivityIndicatorView.Style.large
        indicator.translatesAutoresizingMaskIntoConstraints = false
        self.view.addSubview(indicator)
        NSLayoutConstraint.activate([indicator.centerXAnchor.constraint(equalTo: view.safeAreaLayoutGuide.centerXAnchor), indicator.centerYAnchor.constraint(equalTo: view.safeAreaLayoutGuide.centerYAnchor)
        ])
        
        Task{
            URLSession.shared.invalidateAndCancel()
            await requestrecipes()
        }
        // Do any additional setup after loading the view.
        
        collectionView.collectionViewLayout = UICollectionViewFlowLayout()
    }
    
    //fetch 40 recipe from the user randomly from spoonacular api. tha javascript given by the api will be broken down using recipes and recipe data class.
    func requestrecipes()async{
        guard let requestURL = URL(string: request_string) else{
            print("Invalid URL.")
            return
        }
        
        let urlRequest = URLRequest(url:requestURL)
        
        do{
            let(data, response) = try await URLSession.shared.data(for: urlRequest)
            DispatchQueue.main.async {
                self.indicator.stopAnimating()
            }
            
            do{
                let decoder = JSONDecoder()
                let recipeData = try decoder.decode(RecipesData.self, from: data)
                if let recipe = recipeData.recipes{
                    newrecipe.append(contentsOf: recipe)
                    for _ in newrecipe{
                        recipeimages.append(nil)
                    }
                    collectionView.reloadData()
                    }
                }
        }catch let error{
            print(error)
        }
    }
    
    // set each collection the same size.
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, sizeForItemAt indexPath: IndexPath) -> CGSize {
        return CGSize(width:190, height: 175)
    }
    
    // return number of section in the collection view
    override func numberOfSections(in collectionView: UICollectionView) -> Int {
        // #warning Incomplete implementation, return the number of sections
        return 1
    }

    // return numer of rows in a section for collection view.
    override func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        // #warning Incomplete implementation, return the number of items
        return newrecipe.count
    }

    // instantiate the information on each cell in the collection view and download all the recipe image before display.
    override func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "RecipeCollectionViewCell", for: indexPath) as! RecipeCollectionViewCell
    
        // Configure the cell
        let recipe = newrecipe[indexPath.row]
        cell.recipetitle.text = recipe.title
        
        cell.recipeImage?.image = recipeimages[indexPath.row]
        if cell.recipeImage?.image == nil{
            imageisDownloading = false
        }

        if let image = recipeimages[indexPath.row]{
            cell.recipeImage?.image = image
        }
        else if imageisDownloading == false, let imageURL = recipe.imageURL{
            let requestURL = URL(string: imageURL)
            if let requestURL{
                Task {
                    print("Downloading image: " + imageURL)
                    imageisDownloading = true
                    do{
                        let (data, response) = try await URLSession.shared.data(from:requestURL)
                        guard let httpResponse = response as? HTTPURLResponse,
                              httpResponse.statusCode == 200 else {
                            imageisDownloading = false
                            throw RecipeDetailError.invalidServerResponse
                        }
                        if let image = UIImage(data: data){
                            print("Image downloaded successfully: " + imageURL)
                            //cropimage
                            let croppedImage = cropimage(image: image)
                            recipeimages[indexPath.row] = croppedImage
                            await MainActor.run{
                                collectionView.reloadItems(at:[indexPath])
                            }
                        }
                        else{
                            print("Image invalid: " + imageURL)
                            imageisDownloading = false
                        }
                    }
                    catch{
                        print(error.localizedDescription)
                    }
                }
            }
            else{
                print("Error: URL not valid: " + imageURL)
            }
        }
        return cell
    }
    
    // allow every collection view cell to be selected.
    override func collectionView(_ collectionView: UICollectionView, shouldSelectItemAt indexPath: IndexPath) -> Bool {
        return true
    }
    
    // if a cell was being selected segue to a different controller
    override func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
        selectedrecipe = newrecipe[indexPath.row]
        selectedrecipeimage = recipeimages[indexPath.row]
        performSegue(withIdentifier: SEGUETORECIPEINFORMATIONTABLE , sender: self)
    }
    
    // recipe information selected will be sent to the respective controller before segue.
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        if segue.identifier == SEGUETORECIPEINFORMATIONTABLE{
            let destination = segue.destination as! EATINTableViewController
            destination.recipeinfo = selectedrecipe
            destination.recipedownloadedimage = selectedrecipeimage
        }
    }
    
    // crop all the downloaded image in to square before display.
    func cropimage(image: UIImage) -> UIImage?{
        let sideLength = min(image.size.width, image.size.height)
        let originX = (image.size.width - sideLength) / 2
        let originY = (image.size.height - sideLength) / 2
        let cropRect = CGRect(x:originX, y: originY, width: sideLength, height:sideLength)
        guard let cgImage = image.cgImage?.cropping(to: cropRect)else{
            return nil
        }
        return UIImage(cgImage: cgImage)
    }
    
}
