//
//  EatInCollectionViewController.swift
//  FIT3178-Final-Assignment
//
//  Created by Jit Yap on 23/4/2023.
//

import UIKit

protocol SelectedRecipeDelegate: AnyObject{
    func selectrecipe(recipe: RecipeData,recipeexistingimage: UIImage)
}

private let reuseIdentifier = "Cell"

enum RecipeDetailError: Error{
    case invalidServerResponse
    case invalidShowURL
    case invalidRecipeImageURL
}

class EatInCollectionViewController: UICollectionViewController, UICollectionViewDelegateFlowLayout {

    var receivedrecipeimage: UIImage?
    var imageisDownloading = false
    var imageShown = true
    var selectedrecipe: RecipeData?
    var selectedrecipeimage: UIImage?
    
    weak var delegate: (SelectedRecipeDelegate)?
    
    let request_string = "https://api.spoonacular.com/recipes/random?apiKey=c84f3713b66a41bd89bc0057abb44ecf&number=20"
    
    var newrecipe = [RecipeData]()
    var recipeimages = [UIImage?]()
    var indicator = UIActivityIndicatorView()
    
    let SeguetoRecipeInformationName = "eatintorecipeinfosegue" //delete later
    let SEGUETORECIPEINFORMATIONTABLE = "eatintableviewsegue"

    override func viewDidLoad() {
        super.viewDidLoad()

        // Uncomment the following line to preserve selection between presentations
        // self.clearsSelectionOnViewWillAppear = false
        
        // Register cell classes
        self.collectionView!.register(UICollectionViewCell.self, forCellWithReuseIdentifier: reuseIdentifier)
        
        //Add a loading indicator view
        indicator.style = UIActivityIndicatorView.Style.large
        indicator.translatesAutoresizingMaskIntoConstraints = false
        self.view.addSubview(indicator)
        NSLayoutConstraint.activate([indicator.centerXAnchor.constraint(equalTo: view.safeAreaLayoutGuide.centerXAnchor), indicator.centerYAnchor.constraint(equalTo: view.safeAreaLayoutGuide.centerYAnchor)
        ])
        
        Task{
            URLSession.shared.invalidateAndCancel()
            await requestrecipes()
        }
        // Do any additional setup after loading the view.
        
        collectionView.collectionViewLayout = UICollectionViewFlowLayout()
    }
    
    //fetchrecipefunction
    func requestrecipes()async{
        guard let requestURL = URL(string: request_string) else{
            print("Invalid URL.")
            return
        }
        
        let urlRequest = URLRequest(url:requestURL)
        
        do{
            let(data, response) = try await URLSession.shared.data(for: urlRequest)
            DispatchQueue.main.async {
                self.indicator.stopAnimating()
            }
            
            do{
                let decoder = JSONDecoder()
                let recipeData = try decoder.decode(RecipesData.self, from: data)
                if let recipe = recipeData.recipes{
                    newrecipe.append(contentsOf: recipe)
                    for _ in newrecipe{
                        recipeimages.append(nil)
                    }
                    collectionView.reloadData()
                    }
                }
        }catch let error{
            print(error)
        }
    }
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, sizeForItemAt indexPath: IndexPath) -> CGSize {
        return CGSize(width:190, height: 175)
    }
    
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using [segue destinationViewController].
        // Pass the selected object to the new view controller.
    }
    */

    // MARK: UICollectionViewDataSource
    
    

    override func numberOfSections(in collectionView: UICollectionView) -> Int {
        // #warning Incomplete implementation, return the number of sections
        return 1
    }


    override func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        // #warning Incomplete implementation, return the number of items
        return newrecipe.count
    }

    override func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "RecipeCollectionViewCell", for: indexPath) as! RecipeCollectionViewCell
    
        // Configure the cell
        let recipe = newrecipe[indexPath.row]
        cell.recipetitle.text = recipe.title
        
        cell.recipeImage?.image = recipeimages[indexPath.row]
        if cell.recipeImage?.image == nil{
            imageisDownloading = false
        }

        if let image = recipeimages[indexPath.row]{
            cell.recipeImage?.image = image
        }
        else if imageisDownloading == false, let imageURL = recipe.imageURL{
            let requestURL = URL(string: imageURL)
            if let requestURL{
                Task {
                    print("Downloading image: " + imageURL)
                    imageisDownloading = true
                    do{
                        let (data, response) = try await URLSession.shared.data(from:requestURL)
                        guard let httpResponse = response as? HTTPURLResponse,
                              httpResponse.statusCode == 200 else {
                            imageisDownloading = false
                            throw RecipeDetailError.invalidServerResponse
                        }
                        if let image = UIImage(data: data){
                            print("Image downloaded successfully: " + imageURL)
                            recipeimages[indexPath.row] = image
                            await MainActor.run{
                                collectionView.reloadItems(at:[indexPath])
                            }
                        }
                        else{
                            print("Image invalid: " + imageURL)
                            imageisDownloading = false
                        }
                    }
                    catch{
                        print(error.localizedDescription)
                    }
                }
            }
            else{
                print("Error: URL not valid: " + imageURL)
            }
        }
        return cell
    }
    

    
    
    // MARK: UICollectionViewDelegate

    /*
    // Uncomment this method to specify if the specified item should be highlighted during tracking
    override func collectionView(_ collectionView: UICollectionView, shouldHighlightItemAt indexPath: IndexPath) -> Bool {
        return true
    }
    */

    // Uncomment this method to specify if the specified item should be selected
    override func collectionView(_ collectionView: UICollectionView, shouldSelectItemAt indexPath: IndexPath) -> Bool {
        return true
    }
    
    override func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
        selectedrecipe = newrecipe[indexPath.row]
        selectedrecipeimage = recipeimages[indexPath.row]
        performSegue(withIdentifier: SEGUETORECIPEINFORMATIONTABLE , sender: self)
//        performSegue(withIdentifier: SeguetoRecipeInformationName, sender: self)
    }

    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        if segue.identifier == SeguetoRecipeInformationName{
            let destination = segue.destination as! RecipeInformationViewController
            destination.recipeinfo = selectedrecipe
            destination.recipedownloadedimage = selectedrecipeimage
        }
        else if segue.identifier == SEGUETORECIPEINFORMATIONTABLE{
            let destination = segue.destination as! EATINTableViewController
            destination.recipeinfo = selectedrecipe
            destination.recipedownloadedimage = selectedrecipeimage
        }
    }
    /*
    // Uncomment these methods to specify if an action menu should be displayed for the specified item, and react to actions performed on the item
    override func collectionView(_ collectionView: UICollectionView, shouldShowMenuForItemAt indexPath: IndexPath) -> Bool {
        return false
    }

    override func collectionView(_ collectionView: UICollectionView, canPerformAction action: Selector, forItemAt indexPath: IndexPath, withSender sender: Any?) -> Bool {
        return false
    }

    override func collectionView(_ collectionView: UICollectionView, performAction action: Selector, forItemAt indexPath: IndexPath, withSender sender: Any?) {
    
    }
    */

}
