//
//  restaurantData.swift
//  FIT3178-Final-Assignment
//
//  Created by Jit Yap on 5/5/2023.
//

import UIKit

class RestaurantData: NSObject, Decodable{
    
    var name: String
    var imageURL: String?
    var isclosed: Bool?
    var rating: Float?
    var price: String?
    var phone: String?
    var latitude: Double?
    var longitude: Double?
    
    private enum RestaurantInfoKeys: String, CodingKey{
        case name
        case imageURL = "image_url"
        case is_closed
        case rating
        case coordinates
        case price
        case phone
    }
    
    private enum CoordinateKeys: String, CodingKey{
        case latitude
        case longitude
    }
    
    required init(from decoder: Decoder) throws {
        let rootContainer = try decoder.container(keyedBy: RestaurantInfoKeys.self)
        
        name = try rootContainer.decode(String.self, forKey: .name)
        imageURL = try rootContainer.decode(String.self, forKey: .imageURL)
        isclosed = try rootContainer.decode(Bool.self, forKey: .is_closed)
        rating = try rootContainer.decode(Float.self, forKey: .rating)
        price = try rootContainer.decode(String.self, forKey: .price)
        phone = try rootContainer.decode(String.self, forKey: .phone)
        
        let coordinateContainer = try rootContainer.nestedContainer(keyedBy: CoordinateKeys.self, forKey: .coordinates)
        
        latitude = try coordinateContainer.decode(Double.self, forKey: .latitude)
        longitude = try coordinateContainer.decode(Double.self, forKey: .longitude)
    }
}
