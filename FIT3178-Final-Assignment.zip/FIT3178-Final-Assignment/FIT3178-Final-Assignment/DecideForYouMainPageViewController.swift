//
//  DecideForYouMainPageViewController.swift
//  FIT3178-Final-Assignment
//
//  Created by Jit Yap on 23/4/2023.
//

import UIKit

class DecideForYouMainPageViewController: UIViewController {
    
    //2 recipe in the main page
    let request_string = "https://api.spoonacular.com/recipes/random?apiKey=c84f3713b66a41bd89bc0057abb44ecf&number=2"
    let SEGUETORECIPEINFORMATIONTABLE = "eatintableviewfrommainscreensegue"
    
    var newrecipe = [RecipeData]()
    var recipeimages = [UIImage?]()
    
    //selected recipe
    var selectedRecipe: RecipeData?
    var selectedRecipeImage: UIImage?
    
    var indicator = UIActivityIndicatorView()
    var imageisDownloading = false
    var imageShown = true

    
    override func viewDidLoad() {
        super.viewDidLoad()

        //Add a loading indicator view
        indicator.style = UIActivityIndicatorView.Style.large
        indicator.translatesAutoresizingMaskIntoConstraints = false
        self.view.addSubview(indicator)
        NSLayoutConstraint.activate([indicator.centerXAnchor.constraint(equalTo: view.safeAreaLayoutGuide.centerXAnchor), indicator.centerYAnchor.constraint(equalTo: view.safeAreaLayoutGuide.centerYAnchor)
        ])
        // Do any additional setup after loading the view.
        if newrecipe.isEmpty{
            Task{
                URLSession.shared.invalidateAndCancel()
                await requestrecipes()
            }
        }else{
            setuprecipe()
        }

    }
    
    @IBOutlet weak var recipe2name: UIButton!
    @IBOutlet weak var recipe1name: UIButton!
    @IBOutlet weak var recipeimage1: UIImageView!
    @IBOutlet weak var recipeimage2: UIImageView!
    
    @IBAction func Recipe2button(_ sender: Any) {
        selectedRecipe = newrecipe[1]
        selectedRecipeImage = recipeimages[1]
        self.performSegue(withIdentifier: SEGUETORECIPEINFORMATIONTABLE, sender: self)
    }
    
    @IBAction func Recipe1button(_ sender: Any) {
        selectedRecipe = newrecipe[0]
        selectedRecipeImage = recipeimages[0]
        self.performSegue(withIdentifier: SEGUETORECIPEINFORMATIONTABLE, sender: self)
    }
    
    func requestrecipes()async{
        guard let requestURL = URL(string: request_string) else{
            print("Invalid URL.")
            return
        }
        
        let urlRequest = URLRequest(url:requestURL)
        
        do{
            let(data, response) = try await URLSession.shared.data(for: urlRequest)
            DispatchQueue.main.async {
                self.indicator.stopAnimating()
            }
            
            do{
                let decoder = JSONDecoder()
                let recipeData = try decoder.decode(RecipesData.self, from: data)
                if let recipe = recipeData.recipes{
                    newrecipe.append(contentsOf: recipe)
                    for _ in newrecipe{
                        recipeimages.append(nil)
                        }
                    setuprecipe()
                    }
                }
        }catch let error{
            print(error)
        }
    }
    
    func setuprecipe(){
        recipe1name.configuration?.title = newrecipe.first?.title
        recipe2name.configuration?.title = newrecipe.last?.title
        fetchimage(foodindex: 0)
        fetchimage(foodindex: 1)
        recipeimage1.image = recipeimages[0]
        recipeimage2.image = recipeimages[1]
    }
    
    func fetchimage(foodindex: Int){
        var foodimage: UIImageView?
        if foodindex == 0{
            var foodimage = recipe1name
        }else{
            var foodimage = recipe2name
        }
        
        foodimage?.image = nil

        if let image = recipeimages[foodindex]{
            foodimage?.image = image
        }
        else if imageisDownloading == false, let imageURL = newrecipe[foodindex].imageURL{
            let requestURL = URL(string: imageURL)
            if let requestURL{
                Task {
                    print("Downloading image: " + imageURL)
                    imageisDownloading = true
                    do{
                        let (data, response) = try await URLSession.shared.data(from:requestURL)
                        guard let httpResponse = response as? HTTPURLResponse,
                              httpResponse.statusCode == 200 else {
                            imageisDownloading = false
                            throw RecipeDetailError.invalidServerResponse
                        }
                        if let image = UIImage(data: data){
                            print("Image downloaded successfully: " + imageURL)
                            recipeimages[foodindex] = image
                            await MainActor.run{
                                viewDidLoad()
                            }
                        }
                        else{
                            print("Image invalid: " + imageURL)
                            imageisDownloading = false
                        }
                    }
                    catch{
                        print(error.localizedDescription)
                    }
                }
            }
            else{
                print("Error: URL not valid: " + imageURL)
            }
        }
    }
    
    
    @IBOutlet weak var restaurantimage1: UIImageView!
    @IBOutlet weak var restaurantimage2: UIImageView!
    
    @IBAction func restaurantbutton1(_ sender: Any) {
        self.performSegue(withIdentifier: "restaurantsegue", sender: self)
    }
    @IBAction func restaurantbutton2(_ sender: Any) {
        self.performSegue(withIdentifier: "restaurantsegue", sender: self)
    }
    
    
    @IBAction func eatinbutton(_ sender: Any) {
        self.performSegue(withIdentifier: "eatinsegue", sender: self)
    }
    
    @IBAction func eatoutbutton(_ sender: Any) {
        self.performSegue(withIdentifier: "eatoutviewcontrollersegue", sender: self)
        // eatoutsegue
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        if segue.identifier == SEGUETORECIPEINFORMATIONTABLE{
            let destination = segue.destination as! EATINTableViewController
            destination.recipeinfo = selectedRecipe
            destination.recipedownloadedimage = selectedRecipeImage
        }
    }
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
