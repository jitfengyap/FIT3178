//
//  RestaurantInfoCollectionViewCell.swift
//  FIT3178-Final-Assignment
//
//  Created by Jit Yap on 3/5/2023.
//

import UIKit

class RestaurantInfoCollectionViewCell: UICollectionViewCell {
    
    
    @IBOutlet weak var restaurantimage: UIImageView!
    @IBOutlet weak var restaurantname: UILabel!
    
}
