//
//  ChartsTableViewCell.swift
//  FIT3178-Final-Assignment
//
//  Created by Jit Yap on 26/5/2023.
//

import UIKit

class ChartsTableViewCell: UITableViewCell {

    // uiview connected from statsistic table view controller
    @IBOutlet weak var Chartsview: UIView!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
