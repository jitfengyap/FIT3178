//
//  ChartsUIView.swift
//  FIT3178-Final-Assignment
//
//  Created by Jit Yap on 26/5/2023.
//

import SwiftUI
import Charts

// initialize the data being used for each data in the chart
struct NutritionStructure: Identifiable{
    var name: String
    var calorieCount: Double
    var id = UUID()
}

// create chartuiview that conforms with view. Data will be instatiated as an array of nutritionstructure data
// nutritions data will be inputted in to data to act as a format for future uses.
struct ChartUIView: View {
    var data:[NutritionStructure] = [
        .init(name: "Carbohydrates", calorieCount: 0),
        .init(name: "Protein", calorieCount: 0),
        .init(name: "Fats", calorieCount: 0)]
    
    //craete a bar chart base on the data array above and change the color to gradient orange using foregroundstyle
    var body: some View {

        Chart(data) { NutritionData in
            BarMark(x: .value("Name", NutritionData.name),
                    y: .value("Amount", NutritionData.calorieCount))
            .foregroundStyle(Color.orange.gradient)
        }
    }
    // this function is for replacing all the old data being used in the chartuiview.
    mutating func addChartData(protein: Double, carbs:Double, fats: Double){
        data = [.init(name: "Carbohhydrates", calorieCount: carbs),
                .init(name: "Protein", calorieCount: protein),
                .init(name: "Fats", calorieCount: fats)]
    }
}
