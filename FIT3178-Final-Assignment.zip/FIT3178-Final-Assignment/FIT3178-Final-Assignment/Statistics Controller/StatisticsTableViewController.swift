//
//  StatisticsTableViewController.swift
//  FIT3178-Final-Assignment
//
//  Created by Jit Yap on 21/5/2023.
//

import UIKit
import SwiftUI

class StatisticsTableViewController: UITableViewController, DatabaseListener {
    
    let CALORIE_CELL = "caloriecell"
    let CARB_CELL = "carbcell"
    let PROTEIN_CELL = "proteincell"
    let fats_CELL = "fatcell"
    let CHART_CELL = "Chartcell"
    
    let SECTION_CALORIE = 0
    let SECTION_CARBS = 1
    let SECTION_PROTEIN = 2
    let SECTION_FATS = 3
    let SECTION_CHART = 4
    
    var total_calorie = 0
    var total_carbs = 0
    var total_protein = 0
    var total_fats = 0
    var chartview : ChartUIView?
    
    var listenerType: ListenerType = .nutrition
    
    var allNutritions: [Nutritions] = []
    weak var databaseController: DatabaseProtocol?
    
    // initilize coredata app delegate
    override func viewDidLoad() {
        super.viewDidLoad()

        let appDelegate = (UIApplication.shared.delegate as? AppDelegate)
        databaseController = appDelegate?.databaseController
        // Uncomment the following line to preserve selection between presentations
        // self.clearsSelectionOnViewWillAppear = false

        // Uncomment the following line to display an Edit button in the navigation bar for this view controller.
        // self.navigationItem.rightBarButtonItem = self.editButtonItem
    }
    
    // create a title for each tableviewcell depending on the section number.
    override func tableView(_ tableView: UITableView, titleForHeaderInSection section: Int) -> String? {
        if section == SECTION_CALORIE{
            return "Total calorie"
        }else if section == SECTION_PROTEIN{
            return "Total protein"
        }else if section == SECTION_CARBS{
            return "Total carbs"
        }else if section == SECTION_FATS{
            return "Total fats"
        }else{
            return "Nutritions Data"
        }
    }
    
    // if the table view appear add listener to the database controller and get a acquire a new set of data from the coredata
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        databaseController?.addListener(listener: self)
    }
    
    // if the table view disappeared remove listener from the database controller
    override func viewWillDisappear(_ animated: Bool) {
        super.viewWillDisappear(animated)
        databaseController?.removeListener(listener: self)
    }
    
    // does not relate to this class since it only stores nutritions not the recipe itself.
    func onRecipeListChange(change: DatabaseChange, recipeList: [Recipe]) {
        
    }
    
    // get the new nutriitions when the database have been updated and refresh the entire table view with the updated data from core data
    func onnutritionChange(change: DatabaseChange, nutritions: [Nutritions]) {
        allNutritions = nutritions
        tableView.reloadData()
    }

    // MARK: - Table view data source

    // return number of sections in the table view. if theres no saved nutrition, then does not need to show the fifth cell
    override func numberOfSections(in tableView: UITableView) -> Int {
        // #warning Incomplete implementation, return the number of sections
        if allNutritions.count == 0 {
            return 4
        }
        return 5
    }

    // return number of rows in the section, for cell 0-3 will return count of nutritions and cell 4 will be displayed once because we will only need to see 1 chart.
    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        // #warning Incomplete implementation, return the number of rows
        if section == SECTION_CHART{
            return 1
        }
        return allNutritions.count
    }
    
    // display all the information for each row in the cell based on the list all Nutritions. Each nutritions number will be extracted via regex
    // and append alltogether into their respective variables total_(nutrient_name). the chart cell will call the custom cell called chartstableviewcell in which
    // it consists of a uiview. this view will be used to display the chart. the chart struct called chartuiview will be called and to be place inside the uiview
    // the chart struct will be display will be fixed to the width and length of the uiview in chartstableviewcell
    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let row_recipe = allNutritions[indexPath.row]
        
        if indexPath.section == SECTION_CALORIE{
            let caloriecell = tableView.dequeueReusableCell(withIdentifier: CALORIE_CELL, for: indexPath)
            var caloriecontent = caloriecell.defaultContentConfiguration()
            caloriecontent.text = row_recipe.calorie! + " calorie"
            caloriecell.contentConfiguration = caloriecontent
            let str = row_recipe.calorie
            total_calorie += getNumbers(from: row_recipe.calorie!)[0]
            
            return caloriecell
        }
        else if indexPath.section == SECTION_CARBS{
            let carbscell = tableView.dequeueReusableCell(withIdentifier: CARB_CELL, for: indexPath)
            var carbcontent = carbscell.defaultContentConfiguration()
            carbcontent.text = row_recipe.carbs
            carbscell.contentConfiguration = carbcontent
            total_carbs += getNumbers(from: row_recipe.carbs!)[0]
            
            return carbscell
        }
        else if indexPath.section == SECTION_FATS{
            let fatscell = tableView.dequeueReusableCell(withIdentifier: fats_CELL, for: indexPath)
            var fatcontent = fatscell.defaultContentConfiguration()
            fatcontent.text = row_recipe.fats
            fatscell.contentConfiguration = fatcontent
            total_fats += getNumbers(from: row_recipe.fats!)[0]
            
            return fatscell
        }
        else if indexPath.section == SECTION_PROTEIN{
            let proteincell = tableView.dequeueReusableCell(withIdentifier: PROTEIN_CELL, for: indexPath)
            var proteincontent = proteincell.defaultContentConfiguration()
            proteincontent.text = row_recipe.protein
            proteincell.contentConfiguration = proteincontent
            total_protein += getNumbers(from: row_recipe.protein!)[0]
            
            return proteincell
        }
        else{
            let chartcell = tableView.dequeueReusableCell(withIdentifier: CHART_CELL, for: indexPath) as! ChartsTableViewCell
            let controller = UIHostingController(rootView: ChartUIView())
            
            guard let chartView = controller.view else{
                return chartcell
            }
            
            chartcell.Chartsview.addSubview(chartView)
            self.addChild(controller)
            
            controller.rootView.addChartData(protein: Double(total_protein), carbs: Double(total_carbs), fats: Double(total_fats))
            chartView.translatesAutoresizingMaskIntoConstraints = false

            NSLayoutConstraint.activate([
                chartView.heightAnchor.constraint(equalTo:  chartcell.Chartsview.heightAnchor),
                chartView.widthAnchor.constraint(equalTo: chartcell.Chartsview.widthAnchor)
            ])
            return chartcell
        }
    }
    
    // acquire the numbers that from string using regex. it checks for every character stored in the given string and will seperate each set of number in to a string.
    func getNumbers(from text: String) -> [Int]{
        let regex = try! NSRegularExpression(pattern: "\\d+")
        let matches = regex.matches(in: text, range: NSRange(text.startIndex..., in: text))
        
        return matches.map{ match in
            Int(String(text[Range(match.range, in: text)!]))!
        }
    }
    
    // only let the calorie section to edit.
    override func tableView(_ tableView: UITableView, canEditRowAt indexPath: IndexPath) -> Bool {
        if indexPath.section == SECTION_CALORIE {
            return true
        }
        return false
    }
    
    // if the row is deleting we will be deleting the data stored in its respective location in allNutritions array
    // reload the entire data to acommodate the updated data.
    override func tableView(_ tableView: UITableView, commit editingStyle: UITableViewCell.EditingStyle, forRowAt indexPath: IndexPath) {
        if editingStyle == .delete && indexPath.section == SECTION_CALORIE{
            self.databaseController?.removenutrition(nutritions: allNutritions[indexPath.row])
            tableView.reloadData()
        }
    }
    
    
    
}
